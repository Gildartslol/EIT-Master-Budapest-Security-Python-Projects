import random
import hashlib


def string2numeric_hash(text):
    text = text.encode('utf-8')
    return int(hashlib.md5(text).hexdigest()[:8], 16)


g = 13  # generator
x = 11
p = 47  # prime
v = 7

print('g=', g)
print('p=', p)
print('x=', x, ' (the secret)')
print('v=', v, ' (random)')
print('------> Alice computes <-------')

y = g ** x
t = g ** v
print('t or conmitment=', t)
print('y=', y)

print('Commitment is : ', t)
text_full = str(g) + str(y) + str(t)
c = string2numeric_hash(text_full)
c = c % p
print('c=', c)
r = v - c * x
print('-----------')
print('Alice sends (t,r)=(', str(t), ',', r, ')')
print('Challenge is ', c)

t1 = (g ** r)
t2 = (y ** c)
val = int(t1 * t2)

print('My calculation for g^r x y^c=', val)
if val == t:
    print("Calculation and Commitment t are  = ", t, ". So, Alice prove its ID")
else:
    print("Fraud")
